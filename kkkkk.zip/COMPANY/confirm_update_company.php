<?php
	include("condb.php");
	$addID=$_POST['com_ID'];
	$addName=$_POST['company'];
	$addForm= $_POST['form_bus'];
	$addAddress=$_POST['address'];
	$addContactP=$_POST['contact_p'];
	$addCon_Pos=$_POST['contact_pos'];
	$addFocalP=$_POST['focal_p'];
	$addFocalPos=$_POST['focal_pos'];
	$addCont=$_POST['contact_num'];
	$addCel=$_POST['cel_num'];
	$addEmail=$_POST['email'];
	$addMoa=$_POST['moa'];
	$sql= "update tbl_company set company='$addName', 
	form_bus='$addForm',
	address='$addAddress',
	contact_p='$addContactP',
	contact_pos='$addCon_Pos',
	focal_p='$addFocalP',
	focal_pos='$addFocalPos',
	contact_num='$addCont',
	cel_num='$addCel',
	email='$addEmail',
	moa='$addMoa'
	 where com_ID='$addID';

	
	";
	
	
	
	$result = $conn -> query ($sql);
if ($result){	
 header("location:show.php");
}
else {
 header("location:show.php");
}



?>

<a href="show.php">Show</a>