<!DOCTYPE html>
<html lang="en">
<head>
<link rel="shortcut icon" type="image/x-icon" href="image/logo.png" />

  <title>Add Company</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">   
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<link rel="stylesheet"href="style/style.css">
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link href="https://fonts.googleapis.com/css?family=Oleo+Script+Swash+Caps" rel="stylesheet">
<style>
.navbar-brand{
	margin-right: -200pt;
}
navbar-nav{
	text-align: right;
}
.logo-bg{
width:20%;
 height:10%;
}
@media screen and (max-width: 1000px){
   body{
   overflow-x: hidden;
   }
	.logo-bg{
	width:30px; 
	height:10%;
	}
	h1.title{
	
	font-size: 32pt;
	text-align:center;
	vertical-align: middle;
}
	}
body{
font-family: Roboto;}
#space{
	padding-left:50pt;
}
#me{
padding-right: 20pt;
}




	body{
	
	}
	form{
	display: block;
	position: relative;
	width: 400px;
	height: 1000px;
	background: #fff;
	margin: 50px auto;
	padding: 30px;
	color: white;
    box-cshadow: 2px 2px 4px #000000;
	

	}
	
	label{
	display: block;
	position: relative;
	top: -20px;
	left: 0px;
	color: #999;
	font-family: Calibri Light;
	font-size: 16px;
	z-index: 1;
	transition: all 0.3s ease-in;
	
	}
	input {
	display: block;
	position: relative;
	background: none;
	border: none;
	border-bottom: 1px solid #ddd;
	width: 80%;
	font-family: Calibri Light;
	
	font-size: 16px;
	z-index: 2;
	}	
	
	input:focus, input:valid{
	outline:none;
	border-bottom: 1px solid #00aced;
	
	}
	
	input:focus + label, input:valid + label {
	top: -40px;
	font-size: 11px;
	color:#00aced;
	}
	.divider{
	position: 50px;
	height: 30px;
	width: auto;
	background: none;
	}



	::placeholder {
    color: #999;
    opacity: 1; /* Firefox */
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
   color: #999;
}

::-ms-input-placeholder { /* Microsoft Edge */
   color: #ddd;
}








</style>
</head>
<body>

<!--PAGE 1 0f 2 for THIS IS A DEFAULT DESIGN -->
<nav class="navbar navbar-toggleable-md navbar-light bg-faded navbar-inverse navbar-fixed-top"  id="he" style="background-color:#2C292D; color: white;  ">
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="#"><img src="image/logo.png"  class="logo-bg"></a>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
     

	 <a class="nav-item nav-link" href="#" id="space"><i class="material-icons" id="me">home</i>Home<span class="glyphicon glyphicon-cloud"></span></a>
	  <a class="nav-item nav-link " href="studentlist.php" id="space">
	  
	 <i class="material-icons" id="me">account_circle</i> 
	  Employees</a>
      <a class="nav-item nav-link" href="company.php" id="space">
	  
	  <i class="material-icons" id="me">note_add</i> 
	  Add Company</a>
      <a class="nav-item nav-link" href="show.php"id="space">
	  <i class="material-icons" id="me">business_center</i>Company</a>
      <a class="nav-item nav-link " href="../index.php" id="space">
	  
	  <i class="material-icons">exit_to_app</i>
	  Exit</a>
	 
    </div>
  </div>
</nav>
<!--PAGE 2 0f 2 for THIS IS A DEFAULT DESIGN -->
 <!--EDITING PART-->
 
 <div ="container2"  >
<div class="me" style="    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
   
	
	 height: 20vh;
	 width: 100%;
	 
">

	<h1 class="title" style=" font-family: 'Raleway', cursive;  ">Company</h1>


</div>
			<form action="confirm_insert_company.php" method="POST">
<div class="divider"></div>
		<input type="text" name="company" required autocomplete= "off"/>
		<label for="company">Company Name</label>
		<div class="divider"></div>

		<input type="text" list="business" name="form_bus" required autocomplete= "off" placeholder="Form of Business";"/>
  <datalist id="business">
    <option value="IT Consulting">
    <option value="Hotel">
    <option value="Water Company">
    <option value="Aviation">
    <option value="Restaurant">
    <option value="Bank">
    <option value="Web Development">
    <option value="Government">
    <option value="Department Store">
    <option value="School">
    <option value="Hospital">
    <option value="Past food Chain">
    <option value="Electronics Services">
    <option value="Computer Supplier">
  </datalist>
		<div class="divider"></div>
		
	<!--Company Address-->
		<input type="text" name="address" required autocomplete= "off"/>
	<label for="address">Company Address</label>
<div class="divider"></div>	

<!--Contact Person-->
		<input type="text" name="contact_p" required autocomplete= "off"/>
		<label for="contact_p">Contact Person</label>
	<div class="divider"></div>		

	
	
	
	
	
	
		<!--POSTION-->
	<input type="text" name="contact_pos" required autocomplete= "off"/>
		<label for="contact_pos">Position</label>
	<div class="divider"></div>	
	
	<!--FOCAL PERSON-->

<input type="text" name="focal_p" required autocomplete= "off"/>
		<label for="focal_p">Focal Person</label>
	<div class="divider"></div>	

	<!--FOCAL'S POSTION-->
<input type="text" name="focal_pos" required autocomplete= "off"/>
		<label for="focal_pos">Position</label>
	<div class="divider"></div>	

	<!--CONTACT NUMBER-->
<input type="text" name="contact_num" required autocomplete= "off"/>
		<label for="contact_num">Contact Number</label>
	<div class="divider"></div>	

	<!--CELLPHONE NUMBER-->
<input type="text" name="cel_num" required autocomplete= "off"/>
		<label for="cel_num">Cellphone Number</label>
	<div class="divider"></div>	


	<!--EMAIL-->
<input type="text" name="email" required autocomplete= "off"/>
		<label for="email">Email</label>
	<div class="divider"></div>

	<!--MOA-->
<input type="text" name="moa" required autocomplete= "off"/>
		<label for="moa">Memorandum of Agreement</label>
	<div class="divider"></div>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

		<input type= "submit" name="submit" value="Add" >
		
		</form>

</div>

</body>
</html>