<?php 
include ("condb.php");
$delete_ID= $_GET ['com_ID'];


$sql= "delete from tbl_company where com_ID=$delete_ID";






$result = $conn -> query ($sql);
if ($result){	
 header("location:show.php");
}
else {
 header("location:show.php");}


?>