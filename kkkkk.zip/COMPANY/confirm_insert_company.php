<?php
	include("condb.php");
	$addName=$_POST['company'];
	$addForm= $_POST['form_bus'];
	$addAddress=$_POST['address'];
	$addContactP=$_POST['contact_p'];
	$addCon_Pos=$_POST['contact_pos'];
	$addFocalP=$_POST['focal_p'];
	$addFocalPos=$_POST['focal_pos'];
	$addCont=$_POST['contact_num'];
	$addCel=$_POST['cel_num'];
	$addEmail=$_POST['email'];
	$addMoa=$_POST['moa'];
	$sql= "insert into tbl_company (company, 
	form_bus,
	address,
	contact_p,
	contact_pos,
	focal_p,
	focal_pos,
	contact_num,
	cel_num,
	email,
	moa)
	values(
	'$addName',
	'$addForm',
	'$addAddress',
	'$addContactP',
	'$addCon_Pos',
	'$addFocalP',
	'$addFocalPos',
	'$addCont',
	'$addCel',
	'$addEmail',
	'$addMoa'
	
	
	)
	
	";
	
	
	
	$result = $conn -> query ($sql);
if ($result){	
 header("location:show.php");
}
else {
 header("location:show.php");
}



?>

<a href="show.php">Show</a>