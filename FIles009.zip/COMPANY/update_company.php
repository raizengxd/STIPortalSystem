<html>
<head>
</head>
<style>
form{
	display: block;
	position: relative;
	width: 400px;
	height: 1000px;
	background: #fff;
	margin: 50px auto;
	padding: 30px;
	color: white;
    box-cshadow: 2px 2px 4px #000000;
	

	}
	
	label{
	display: block;
	position: relative;
	top: -20px;
	left: 0px;
	color: #999;
	font-family: Calibri Light;
	font-size: 16px;
	z-index: 1;
	transition: all 0.3s ease-in;
	
	}
	input {
	display: block;
	position: relative;
	background: none;
	border: none;
	border-bottom: 1px solid #ddd;
	width: 80%;
	font-family: Calibri Light;
	
	font-size: 16px;
	z-index: 2;
	}	
	
	input:focus, input:valid{
	outline:none;
	border-bottom: 1px solid #00aced;
	
	}
	
	input:focus + label, input:valid + label {
	top: -40px;
	font-size: 11px;
	color:#00aced;
	}
	.divider{
	position: 50px;
	height: 30px;
	width: auto;
	background: none;
	}



	::placeholder {
    color: #999;
    opacity: 1; /* Firefox */
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
   color: #999;
}

::-ms-input-placeholder { /* Microsoft Edge */
   color: #ddd;
}

</style>
<body>
<?php
include("condb.php");
$update_ID= $_GET['com_ID'];
	$sql="Select * from tbl_company where com_ID='$update_ID'";

	$result=$conn -> query ($sql);
	$rows=mysqli_num_rows($result);
	$row= $result ->fetch_assoc();
$addID=$row['com_ID'];
$addName=$row['company'];
	$addForm= $row['form_bus'];
	$addAddress=$row['address'];
	$addContactP=$row['contact_p'];
	$addCon_Pos=$row['contact_pos'];
	$addFocalP=$row['focal_p'];
	$addFocalPos=$row['focal_pos'];
	$addCont=$row['contact_num'];
	$addCel=$row['cel_num'];
	$addEmail=$row['email'];
	$addMoa=$row['moa'];
	?>
	
					<form action="confirm_update_company.php" method="POST">
<div class="divider"></div>
<input type="text" name="com_ID" required autocomplete= "off" value="<?php echo $update_ID ?>"/>
		<label for="com_ID">Company No</label>
		<div class="divider"></div>


		<input type="text" name="company" required autocomplete= "off" value="<?php echo $addName ?>"/>
		<label for="company">Company Name</label>
		<div class="divider"></div>

		<input type="text" list="business" value="<?php echo $addForm?>"= name="form_bus" required autocomplete= "off" placeholder="Form of Business";"/>
  <datalist id="business">
    <option value="IT Consulting">
    <option value="Hotel">
    <option value="Water Company">
    <option value="Aviation">
    <option value="Restaurant">
    <option value="Bank">
    <option value="Web Development">
    <option value="Government">
    <option value="Department Store">
    <option value="School">
    <option value="Hospital">
    <option value="Past food Chain">
    <option value="Electronics Services">
    <option value="Computer Supplier">
  </datalist>
		<div class="divider"></div>
		
	<!--Company Address-->
		<input type="text" name="address" required autocomplete= "off" value="<?php echo $addAddress?>"/>
	<label for="address">Company Address</label>
<div class="divider"></div>	

<!--Contact Person-->
		<input type="text" name="contact_p" required autocomplete= "off" value="<?php echo $addContactP ?>"/>
		<label for="contact_p">Contact Person</label>
	<div class="divider"></div>		

	
	
	
	
	
	
		<!--POSTION-->
	<input type="text" value="<?php echo $addCon_Pos?>" name="contact_pos" required autocomplete= "off"/>
		<label for="contact_pos">Position</label>
	<div class="divider"></div>	
	
	<!--FOCAL PERSON-->

<input type="text" name="focal_p" value="<?php echo$addFocalP ?>"required autocomplete= "off"/>
		<label for="focal_p">Focal Person</label>
	<div class="divider"></div>	

	<!--FOCAL'S POSTION-->
<input type="text" value="<?php echo $addFocalPos?>" name="focal_pos" required autocomplete= "off"/>
		<label for="focal_pos">Position</label>
	<div class="divider"></div>	

	<!--CONTACT NUMBER-->
<input type="text" value="<?php echo $addCont?>"name="contact_num" required autocomplete= "off"/>
		<label for="contact_num">Contact Number</label>
	<div class="divider"></div>	

	<!--CELLPHONE NUMBER-->
<input type="text" value="<?php echo $addCel ?>" name="cel_num" required autocomplete= "off"/>
		<label for="cel_num">Cellphone Number</label>
	<div class="divider"></div>	


	<!--EMAIL-->
<input type="text" value="<?php echo $addEmail?>" name="email" required autocomplete= "off"/>
		<label for="email">Email</label>
	<div class="divider"></div>

	<!--MOA-->
<input type="text" name="moa" required autocomplete= "off" value="<?php echo $addMoa?>"/>
		<label for="moa">Memorandum of Agreement</label>
	<div class="divider"></div>
	

		<input type= "submit" name="submit" value="Update" >
		
		</form>
		
</body>		
</html>